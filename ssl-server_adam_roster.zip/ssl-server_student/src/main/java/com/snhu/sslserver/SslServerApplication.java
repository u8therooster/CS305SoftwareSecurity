package com.snhu.sslserver;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.util.Base64;

@RestController
public class SslServerApplication {

    private final AesEncryptionService encryptionService = new AesEncryptionService();

    @GetMapping("/encrypt")
    public String encryptAndReturnChecksum() {
        String message = "Hello World";
        String encryptedMessage = encryptionService.encrypt(message);

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(encryptedMessage.getBytes());
            String checksum = Base64.getEncoder().encodeToString(hash);
            return "Encrypted Message: " + encryptedMessage + " Checksum: " + checksum;
        } catch (Exception e) {
            return "Error generating checksum";
        }
    }
}
